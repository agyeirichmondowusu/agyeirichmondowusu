package com.workspace.front;

import android.annotation.SuppressLint;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ListView;
import java.util.List;
import java.util.Objects;

public class AppsFragment extends Fragment {

    AppHomeListViewAdapter adapter;
    ListView fragmentAppsList;

    @Nullable
    @Override
    public Animation onCreateAnimation(int transit, boolean enter, int nextAnim) {
        if (enter)
            return AnimationUtils.loadAnimation(requireContext(), R.anim.slide_left_enter);
        else
            return super.onCreateAnimation(transit, false, nextAnim);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View appFragmentView = inflater.inflate(R.layout.fragment_apps, container, false);
        fragmentAppsList = appFragmentView.findViewById(R.id.appsFragmentListView);

        adapter = new AppHomeListViewAdapter(requireContext(), R.layout.app_status, AppsStatus.appsStatusList);
        adapter.notifyDataSetChanged();
        fragmentAppsList.setAdapter(adapter);

        return appFragmentView;
    }


    @Override
    public void onResume() {
        adapter = new AppHomeListViewAdapter(requireContext(), R.layout.app_status, AppsStatus.appsStatusList);
        adapter.notifyDataSetChanged();
        fragmentAppsList.setAdapter(adapter);

        super.onResume();
    }
}