package com.workspace.front;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.timepicker.MaterialTimePicker;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AppsConfigActivity extends AppCompatActivity {
    ExecutorService service;
    Handler handler;
    AppsDB db;
    LinearLayout appInfoLayout;
    static Drawable icon;
    static String label;
    static String packageName;
    ImageView selectedAppIcon;
    TextView selectedAppLabel;
    AppCompatButton btnSave, btnCancel;
    MaterialTimePicker maTimePicker;
    TextView timeSet;
    private String time;

    FloatingActionButton btnAddTime, btnAddApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apps_config);
        maTimePicker = CreatePicker.createTimePicker();
        service = Executors.newSingleThreadExecutor();
        handler = new Handler(Looper.getMainLooper());

        appInfoLayout = findViewById(R.id.displayAppInfo);
        db = new AppsDB(this);

        selectedAppLabel = findViewById(R.id.appConfigLabel);
        selectedAppIcon = findViewById(R.id.appConfigIcon);
        btnCancel = findViewById(R.id.appsBtnCancel);
        btnSave = findViewById(R.id.appsBtnSave);

        btnAddApp = findViewById(R.id.configFabAddApp);
        btnAddTime = findViewById(R.id.appConfigFabSetTime);
        timeSet = findViewById(R.id.appTimeSet);

        btnSave.setOnClickListener(view -> {

            if(timeSet.getText().toString().isEmpty()){
                Toast.makeText(this, getString(R.string.please_set_time), Toast.LENGTH_SHORT).show();
            }
            if(selectedAppLabel.getText().toString().isEmpty()){
                Toast.makeText(this, getString(R.string.please_select_an_app), Toast.LENGTH_SHORT).show();
            }
            if(!timeSet.getText().toString().isEmpty() && !selectedAppLabel.getText().toString().isEmpty()){
                if(db.addPackage(new AppPackageNames(packageName, time))){
                    Toast.makeText(this, getString(R.string.saved), Toast.LENGTH_SHORT).show();
                    Apps.appsList.add(new Apps(icon, label, packageName));
                    if(!time.isEmpty()){
                        AppsStatus.appsStatusList.add(new AppsStatus(true, new Apps(icon, label, packageName), time));
                    }
                    MainActivity.lastSelectedIndex = 2;
                    onBackPressed();
                }
            }

        });

        btnCancel.setOnClickListener(view -> {
            MainActivity.lastSelectedIndex = 2;
            onBackPressed();
        });

        btnAddTime.setOnClickListener(view -> showAndHandleTimePicker());

        btnAddApp.setOnClickListener(view -> startActivity(new Intent(this, AppsActivity.class)));

    }

    public void showAndHandleTimePicker(){
        maTimePicker.show(getSupportFragmentManager(), getString(R.string.time));
        maTimePicker.addOnPositiveButtonClickListener(p -> {
            time = CreatePicker.formatAlarmTime(maTimePicker.getHour(), maTimePicker.getMinute());
            timeSet.setText(time);
        });

        maTimePicker.addOnNegativeButtonClickListener(n -> maTimePicker.dismiss());

    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public void onBackPressed() {
        MainActivity.lastSelectedIndex = 2;

        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        timeSet.setText(time);
        timeSet.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));
        selectedAppIcon.setImageDrawable(icon);
        selectedAppLabel.setText(label);
        selectedAppIcon.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));
        selectedAppLabel.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));

        super.onResume();
    }
}