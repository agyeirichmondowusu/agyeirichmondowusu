package com.workspace.front;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class ForegroundService extends Service {
    final int requestCode = 110;
    final int foregroundId = 2;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Intent returnToMain = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, requestCode, returnToMain, PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification = new NotificationCompat.Builder(this, "SERVICE_CHANNEL")
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setSilent(true)
                .setAutoCancel(false)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setSmallIcon(R.drawable.ic_notifications)
                .build();

        startForeground(foregroundId, notification);
        return START_NOT_STICKY;
    }

    public void createServiceChannel(){
        String name = "Foreground Service";
        String CHANNEL_ID = "foregroundChannel";
        int importance = NotificationManager.IMPORTANCE_LOW;

        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                name,
                importance

        );

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(this);
        managerCompat.createNotificationChannel(channel);
    }
}
