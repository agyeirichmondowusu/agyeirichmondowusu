package com.workspace.front;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.view.View;

import android.view.animation.AnimationUtils;
import android.webkit.URLUtil;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.timepicker.MaterialTimePicker;

public class LinksActivity extends AppCompatActivity {

    private static final int LINK_DEFAULT_INDEX = 1;
    FloatingActionButton fab, fabAddTime;
    private String time;
    LinkDB db;
    TextView pastedUrl, timeSet, titleSet;
    AppCompatButton btnCancel, btnSave;
    boolean isValidTitle = false;
    boolean isValidLink = false;
    boolean isValidUrl = false;
    boolean isTimeFilled = false;
    boolean isAllValid = false;
    private AlertDialog mainAlertDialog;
    MaterialTimePicker maTimePicker;
    String alarmTitle = "";
    String alarmLink = "";

    ClipboardManager clipboardManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_link);

        fabAddTime = findViewById(R.id.linksFabAddTime);
        fab = findViewById(R.id.linksFab);
        pastedUrl = findViewById(R.id.linkPastedUrl);
        timeSet = findViewById(R.id.linkTxtTimeSet);
        titleSet = findViewById(R.id.linkTitleSet);
        maTimePicker = CreatePicker.createTimePicker();
        mainAlertDialog = createDialog();
        btnCancel = findViewById(R.id.linksBtnCancel);
        btnSave = findViewById(R.id.linksBtnSave);

        clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

        db = new LinkDB(this);

        showAndHandleTimePicker();

        fabAddTime.setOnClickListener(view -> showAndHandleTimePicker());

        fab.setOnClickListener(view -> showAlertDialog());

        btnSave.setOnClickListener(view -> {
            if(!isTimeFilled){
                Toast.makeText(this, getString(R.string.please_set_time), Toast.LENGTH_SHORT).show();
            }else if(!isAllValid){
                Toast.makeText(this, getString(R.string.please_fill_all), Toast.LENGTH_SHORT).show();
            }else if(verifyAllNeededInputs() && isTimeFilled){
                if(db.addLink(new Links(alarmTitle, alarmLink, getTime(), true))){
                    db.getAllLinks();
                    LinksFragment.linksAdapter.notifyDataSetChanged();
                    Toast.makeText(this, getText(R.string.saved), Toast.LENGTH_SHORT).show();
                    MainActivity.lastSelectedIndex = LINK_DEFAULT_INDEX;
                    onBackPressed();

                }
            }else if(isTimeFilled && !isAllValid){
                Toast.makeText(this, getString(R.string.please_fill_all), Toast.LENGTH_SHORT).show();
            }else if(getTime().isEmpty()){
                Toast.makeText(this, getText(R.string.please_set_time), Toast.LENGTH_SHORT).show();
            }else if(alarmTitle.isEmpty()){
                Toast.makeText(this, getText(R.string.please_set_title), Toast.LENGTH_SHORT).show();
            }else if(alarmLink.isEmpty()){
                Toast.makeText(this, getText(R.string.please_paste_link), Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this, getText(R.string.please_review_inputs), Toast.LENGTH_SHORT).show();
            }
        });

        btnCancel.setOnClickListener(view -> onBackPressed());
    }

    @Override
    public void onBackPressed() {
        MainActivity.lastSelectedIndex = LINK_DEFAULT_INDEX;
        super.onBackPressed();
    }

    public void showAndHandleTimePicker(){

        maTimePicker.show(getSupportFragmentManager(), getString(R.string.time));

        maTimePicker.addOnPositiveButtonClickListener(p -> {
            time = CreatePicker.formatAlarmTime(maTimePicker.getHour(), maTimePicker.getMinute());
            timeSet.setText(time);
            isTimeFilled = true;
            timeSet.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));
        });

        maTimePicker.addOnNegativeButtonClickListener(v -> maTimePicker.dismiss());

    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    public AlertDialog createDialog() {
        final AlertDialog.Builder builder;
        builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.links_dialog, null);
        builder.setView(dialogView);

        return builder.create();
    }

    public void showAlertDialog() {
        mainAlertDialog.setCancelable(false);
        mainAlertDialog.show();
//https://www.google.com
        View dialogView = mainAlertDialog.getWindow().getDecorView();
        AppCompatButton btnSave = dialogView.findViewById(R.id.dialogBtnSave);
        AppCompatButton btnCancel = dialogView.findViewById(R.id.dialogBtnCancel);
//        AppCompatButton btnPaste = dialogView.findViewById(R.id.btnPaste);

        EditText titleTxt = dialogView.findViewById(R.id.edtTitle);
        EditText linkTxt = dialogView.findViewById(R.id.edtLink);

        btnSave.setOnClickListener(view -> {
            if (verifyAllNeededInputs()) {
                    alarmTitle = titleTxt.getText().toString().trim();
                    alarmLink = linkTxt.getText().toString().trim();
                    titleSet.setText(titleTxt.getText().toString().trim());
                    pastedUrl.setText(linkTxt.getText().toString().trim());
                    titleSet.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));
                    pastedUrl.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));
                    if(!alarmTitle.isEmpty()){
                        isAllValid = true;
                    }
                    mainAlertDialog.dismiss();
            }
        });

        btnCancel.setOnClickListener(view -> mainAlertDialog.dismiss());
    }
    private boolean verifyAllNeededInputs() {
        View dialogView = mainAlertDialog.getWindow().getDecorView();
        EditText edtTitle = dialogView.findViewById(R.id.edtTitle);
        EditText edtLink = dialogView.findViewById(R.id.edtLink);

            if (edtTitle.getText().toString().trim().isEmpty()) {
                edtTitle.setError(getString(R.string.link_is_required));
                edtTitle.requestFocus();
                isValidTitle = false;
            } else {
                isValidTitle = true;
            }

            if (edtLink.getText().toString().trim().isEmpty()) {
                edtLink.setError(getString(R.string.title_is_required));
                edtLink.requestFocus();
                isValidLink = false;
            } else if (!URLUtil.isValidUrl(edtLink.getText().toString().trim())) {
                isValidUrl = false;
            } else {
                isValidLink = true;
                isValidUrl = true;
            }

            if (edtTitle.getText().toString().trim().isEmpty() && edtLink.getText().toString().trim().isEmpty()) {
                edtTitle.setError(getString(R.string.title_is_required));
                edtTitle.requestFocus();
                edtLink.setError(getString(R.string.link_is_required));
                edtLink.clearFocus();

                isValidTitle = false;
                isValidLink = false;
                isValidUrl = false;
            }


            return isValidTitle && isValidLink && isValidUrl;
        }

    }
