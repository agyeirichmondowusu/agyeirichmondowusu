package com.workspace.front;

import java.util.ArrayList;
import java.util.List;

public class AppsStatus {
    public static List<AppsStatus> appsStatusList = new ArrayList<>();
    private final boolean status;
    private final Apps apps;
    private final String time;

    public AppsStatus(boolean status, Apps apps, String time) {
        this.status = status;
        this.apps = apps;
        this.time = time;
    }

    public boolean getStatus() {
        return status;
    }

    public Apps getApps() {
        return apps;
    }

    public String getTime() {
        return time;
    }
}
