package com.workspace.front;

import com.google.android.material.timepicker.MaterialTimePicker;
import com.google.android.material.timepicker.TimeFormat;

import java.util.Calendar;

public class CreatePicker {

    static MaterialTimePicker createTimePicker(){
        return new MaterialTimePicker.Builder()
                .setTitleText("Set Alarm")
                .setInputMode(MaterialTimePicker.INPUT_MODE_KEYBOARD)
                .setTimeFormat(TimeFormat.CLOCK_12H)
                .setHour(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))
                .setMinute(Calendar.getInstance().get(Calendar.MINUTE))
                .setPositiveButtonText("Save")
                .setNegativeButtonText("Cancel")
                .build();

    }

    static String formatAlarmTime(int hour, int minute){
        String _hour;
        if(hour < 10){
            _hour = "0" + hour;
        }else{
            _hour = "" + hour;
        }
        String _minute;
        if(minute < 10){
            _minute = "0" + minute;
        }else{
            _minute = "" + minute;
        }

        return _hour + ":" + _minute;
    }
}
