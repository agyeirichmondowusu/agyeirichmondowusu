package com.workspace.front;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;

public class App extends Application {

    public static final String TIME_CHANNEL = "timeChannel";
    public static final String APP_CHANNEL = "appChannel";
    public static final String URL_CHANNEL = "urlChannel";

    @Override
    public void onCreate() {
        createTimeChannel();
        createAppChannel();
        createUrlChannel();
        super.onCreate();
    }

    public void createTimeChannel(){
        String name = getString(R.string.time);
        String description = getString(R.string.time_alarm);
        int importance = NotificationManager.IMPORTANCE_HIGH;
        NotificationChannel channel = new NotificationChannel(
                TIME_CHANNEL,
                name,
                importance
        );
        channel.setDescription(description);

        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);
    }
    public void createAppChannel(){
        String name = getString(R.string.app);
        String description = getString(R.string.app_alarm);
        int importance = NotificationManager.IMPORTANCE_HIGH;
        NotificationChannel channel = new NotificationChannel(
                APP_CHANNEL,
                name,
                importance
        );
        channel.setDescription(description);

        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);
    }
    public void createUrlChannel(){
        String name = getString(R.string.url);
        String description = getString(R.string.url_alarm);
        int importance = NotificationManager.IMPORTANCE_HIGH;
        NotificationChannel channel = new NotificationChannel(
                URL_CHANNEL,
                name,
                importance
        );
        channel.setDescription(description);

        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);
    }
}
