package com.workspace.front;

import static com.workspace.front.App.URL_CHANNEL;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class LinkAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String link = intent.getStringExtra("link");

        Intent returnToLinkSection = new Intent(context, MainActivity.class);
        MainActivity.lastSelectedIndex = 1;
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 51, returnToLinkSection, PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new NotificationCompat.Builder(context, URL_CHANNEL)
                .setSmallIcon(R.drawable.ic_notifications)
                .setOngoing(false)
                .setAutoCancel(true)
                .setContentTitle("Url Alarm ")
                .setColor(context.getColor(R.color.sea_blue))
                .setContentText("launching \"" + link + "\"")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .build();

        NotificationManager manager = context.getSystemService(NotificationManager.class);
        manager.notify(223, notification);



        Toast.makeText(context, "Link is received "+ link, Toast.LENGTH_SHORT).show();
        Uri uri = Uri.parse(link);
        Intent launchUrl = new Intent(Intent.ACTION_VIEW, uri);
        launchUrl.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(launchUrl);

    }
}
//https://www.google.com