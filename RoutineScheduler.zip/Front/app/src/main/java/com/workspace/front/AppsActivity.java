package com.workspace.front;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AppsActivity extends AppCompatActivity {
    private static final int APPS_DEFAULT_INDEX = 2;
    InstalledAppsAdapter adapter;
    ListView appsListView;
    AlertDialog.Builder builder;

    AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apps);
        dialog = createDialog();

        appsListView = findViewById(R.id.appsActivityListView);

        appsListView.setOnItemClickListener((adapterView, view, position, id ) -> {
            Apps apps = (Apps) adapterView.getItemAtPosition(position);
            AppsConfigActivity.icon = apps.getIcon();
            AppsConfigActivity.label = apps.getLabel();
            AppsConfigActivity.packageName = apps.getPackageName();
            onBackPressed();
        });

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());
        showDialog();
        executorService.execute(() -> {
//                Background work here
            List<ApplicationInfo> applicationInfoList = getPackageManager().getInstalledApplications(PackageManager.GET_META_DATA);
            List<Apps> appsList = new ArrayList<>();
            for (ApplicationInfo info : applicationInfoList) {
                appsList.add(new Apps(info.loadIcon(getPackageManager()), info.loadLabel(getPackageManager()).toString(), info.packageName));
            }

            handler.post(() -> {
//                UI work
                adapter = new InstalledAppsAdapter(getApplicationContext(), R.layout.app_row_item, appsList);
                adapter.notifyDataSetChanged();
                appsListView.setAdapter(adapter);
                dismissDialog();

            });
        });

    }

    public AlertDialog createDialog() {
        builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.loadingapps_dialog, null);
        builder.setView(dialogView);
        builder.setCancelable(false);

        AlertDialog dialog = builder.create();
        dialog.setCancelable(false);

        return dialog;
    }

    public void showDialog() {
        dialog.setCancelable(false);
        dialog.show();
    }

    public void dismissDialog() {
        dialog.dismiss();
    }

    @Override
    public void onBackPressed() {
        MainActivity.lastSelectedIndex = APPS_DEFAULT_INDEX;
        super.onBackPressed();
    }
}