package com.workspace.front;

import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.List;

public class Apps {
    public static List<Apps> appsList = new ArrayList<>();
    private final Drawable icon;
    private final String label;
    private final String packageName;

    public Apps(Drawable icon, String label, String packageName) {
        this.icon = icon;
        this.label = label;
        this.packageName = packageName;
    }

    public Drawable getIcon() {
        return icon;
    }

    public String getLabel() {
        return label;
    }

    public String getPackageName() {
        return packageName;
    }

    //    public String getPackageName() {
//        return packageName;
//    }
}
