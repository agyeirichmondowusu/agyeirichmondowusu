package com.workspace.front;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;

import java.util.Calendar;
import java.util.List;

public class AppHomeListViewAdapter extends BaseAdapter {
    Context context;
    int resource;
    List<AppsStatus> appsStatusList;
    final Calendar presentCalendar = Calendar.getInstance();
    final Calendar futureCalendar = Calendar.getInstance();
    AlarmManager manager;

    public AppHomeListViewAdapter(Context context, int resource, List<AppsStatus> appsStatusList) {
        this.context = context;
        this.resource = resource;
        this.appsStatusList = appsStatusList;
    }

    @Override
    public int getCount() {
        return appsStatusList.size();
    }

    @Override
    public Object getItem(int position) {
        return appsStatusList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return getView(position, null, null).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if(convertView == null){
            convertView = inflater.inflate(resource, parent, false);
        }
        TextView label = convertView.findViewById(R.id.selectedAppLabel);
        TextView timeSet = convertView.findViewById(R.id.timeSet);
        ImageView icon = convertView.findViewById(R.id.selectedAppIcon);
        SwitchCompat appSwitch = convertView.findViewById(R.id.appSwitch);

        label.setText(appsStatusList.get(position).getApps().getLabel());
        timeSet.setText(appsStatusList.get(position).getTime());
        icon.setImageDrawable(appsStatusList.get(position).getApps().getIcon());
        appSwitch.setChecked(appsStatusList.get(position).getStatus());

        String getTimeSet = appsStatusList.get(position).getTime();
        String[] split_time = getTimeSet.split(context.getString(R.string.time_colon));
        int hour = Integer.parseInt(split_time[0]);
        int minute = Integer.parseInt(split_time[1]);

        presentCalendar.set(Calendar.HOUR_OF_DAY, hour);
        presentCalendar.set(Calendar.MINUTE, minute);
        presentCalendar.set(Calendar.SECOND, 0);
        presentCalendar.set(Calendar.MILLISECOND, 0);

        Intent appIntent = new Intent(context, AppAlarmReceiver.class);
        appIntent.putExtra("packageName", appsStatusList.get(position).getApps().getPackageName());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, position, appIntent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_UPDATE_CURRENT);
        if(presentCalendar.before(Calendar.getInstance())){
            futureCalendar.setTime(presentCalendar.getTime());
            futureCalendar.add(Calendar.DATE, 1);
            manager.setExact(AlarmManager.RTC_WAKEUP, futureCalendar.getTimeInMillis(), pendingIntent);
        }
        else{
            manager.setExact(AlarmManager.RTC_WAKEUP, presentCalendar.getTimeInMillis(), pendingIntent);
        }

        appSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked){
                appSwitch.setChecked(true);
                if(presentCalendar.before(Calendar.getInstance())){
                    futureCalendar.setTime(presentCalendar.getTime());
                    futureCalendar.add(Calendar.DATE, 1);
                    manager.setExact(AlarmManager.RTC_WAKEUP, futureCalendar.getTimeInMillis(), pendingIntent);
                }
                else{
                    manager.setExact(AlarmManager.RTC_WAKEUP, presentCalendar.getTimeInMillis(), pendingIntent);
                }

            }else{
                appSwitch.setChecked(false);
                manager.cancel(pendingIntent);
                pendingIntent.cancel();
            }
        });


        return convertView;
    }
}
