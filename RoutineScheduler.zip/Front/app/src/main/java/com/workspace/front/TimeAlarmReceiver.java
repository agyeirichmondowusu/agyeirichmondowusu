package com.workspace.front;

import static com.workspace.front.App.TIME_CHANNEL;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;

import java.util.Calendar;

public class TimeAlarmReceiver extends BroadcastReceiver {
    final Calendar calendar = Calendar.getInstance();
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent returnToLinkSection = new Intent(context, MainActivity.class);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        String time = hour + context.getString(R.string.time_colon) + minute;
        MainActivity.lastSelectedIndex = 0;
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 52, returnToLinkSection, PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new NotificationCompat.Builder(context, TIME_CHANNEL)
                .setSmallIcon(R.drawable.ic_notifications)
                .setOngoing(false)
                .setAutoCancel(true)
                .setContentTitle(context.getString(R.string.alarm))
                .setColor(context.getColor(R.color.sea_blue))
                .setContentText(context.getString(R.string.alarm_time_up)+" "+time)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .build();

        NotificationManager manager = context.getSystemService(NotificationManager.class);
        manager.notify(224, notification);

        context.startService(new Intent(context, Music.class));

    }
}
