package com.workspace.front;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ListView;
import android.widget.Toast;

public class TimeFragment extends Fragment {
    TimeAdapter adapter;
    TimeDB db;
    ListView timesListView;

    @Nullable
    @Override
    public Animation onCreateAnimation(int transit, boolean enter, int nextAnim) {
        if(enter) {
            return AnimationUtils.loadAnimation(requireContext(), R.anim.slide_left_enter);
        }else {
            return super.onCreateAnimation(transit, false, nextAnim);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View timeFragmentView = inflater.inflate(R.layout.fragment_time, null);
        timesListView = timeFragmentView.findViewById(R.id.listAlarms);
        db = new TimeDB(requireContext());

        adapter = new TimeAdapter(requireContext(), R.layout.time_row_item, Times.myTimeClassList);
        db.getAllTime();
        adapter.notifyDataSetChanged();
        timesListView.setAdapter(adapter);

        timesListView.setOnItemClickListener((adapterView, view, position, id) -> {
            Toast.makeText(requireContext(), "Clicked", Toast.LENGTH_SHORT).show();
            Intent visitActivity = new Intent(requireContext(), TimeActivity.class);

            TimeActivity.setPosition(position);
            Times timeItem = (Times) adapterView.getItemAtPosition(position);
            TimeActivity.savedTime = timeItem.getTime();
            startActivity(visitActivity);
        });

        return timeFragmentView;
    }

    @Override
    public void onResume() {
        adapter = new TimeAdapter(requireContext(), R.layout.time_row_item, Times.myTimeClassList);
        timesListView.setAdapter(adapter);
        super.onResume();
    }
}