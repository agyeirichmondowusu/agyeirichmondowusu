package com.workspace.front;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ListView;

public class LinksFragment extends Fragment {

    LinkDB linkDB;
    @SuppressLint("StaticFieldLeak")
    static LinksAdapter linksAdapter;
    ListView linksListView;
    @Nullable
    @Override
    public Animation onCreateAnimation(int transit, boolean enter, int nextAnim) {
        if(enter) {
            return AnimationUtils.loadAnimation(requireContext(), R.anim.slide_left_enter);
        }else {
            return super.onCreateAnimation(transit, false, nextAnim);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        @SuppressLint("InflateParams")
        View linksView = inflater.inflate(R.layout.fragment_links, null);
        linkDB = new LinkDB(requireContext());
        linksListView = linksView.findViewById(R.id.linksListView);
        linkDB.getAllLinks();
        linksAdapter = new LinksAdapter(requireContext(), R.layout.link_row_item, Links.linksList);


        linksAdapter.notifyDataSetChanged();
        linksListView.setAdapter(linksAdapter);

        return linksView;
    }

}

