package com.workspace.front;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class LinkWorker extends Worker {
    public LinkWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Intent getLink = new Intent(getApplicationContext(), LinkAlarmReceiver.class);
        Uri uri = Uri.parse(getLink.getStringExtra("link"));
        Intent launchUri = new Intent(Intent.ACTION_VIEW, uri);
        launchUri.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        getApplicationContext().startActivity(launchUri);
        return Result.success();
    }
}
