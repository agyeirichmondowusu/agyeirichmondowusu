package com.workspace.front;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;

import java.util.Calendar;
import java.util.List;

public class TimeAdapter extends BaseAdapter {

    Context context;
    int resource;
    List<Times> timesList;
    final Calendar presentTime = Calendar.getInstance();
    final Calendar futureTime = Calendar.getInstance();
    AlarmManager manager;


    public TimeAdapter(Context context, int resource, List<Times> timesList) {
        this.context = context;
        this.resource = resource;
        this.timesList = timesList;
    }

    @Override
    public int getCount() {
        return timesList.size();
    }

    @Override
    public Object getItem(int position) {
        return timesList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return getView(position, null, null).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        if(convertView == null){
            convertView = inflater.inflate(resource, parent, false);
        }
        convertView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.slide_in_bounce));
        TextView txtTimeSet = convertView.findViewById(R.id.time_set);
        SwitchCompat alarmSwitch = convertView.findViewById(R.id.timeAlarmSwitch);
//        if(!timesList.get(position).getTime().isEmpty()){
            txtTimeSet.setText(timesList.get(position).getTime());
            alarmSwitch.setChecked(timesList.get(position).getStatus());
//        }else{
//            Toast.makeText(context, "time is not received", Toast.LENGTH_SHORT).show();
//        }
        

//      Alarm
        String time_set = timesList.get(position).getTime();
        String [] splitTime = time_set.split(":");
        int hour = Integer.parseInt(splitTime[0]);
        int minute = Integer.parseInt(splitTime[1]);

        manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        presentTime.set(Calendar.HOUR_OF_DAY, hour);
        presentTime.set(Calendar.MINUTE, minute);
        presentTime.set(Calendar.SECOND, 0);
        presentTime.set(Calendar.MILLISECOND, 0);

        Intent launcherIntent = new Intent(context, TimeAlarmReceiver.class);
        launcherIntent.setAction("com.intent");
        launcherIntent.putExtra("requestCode", position);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, position, launcherIntent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);

//        if(!isAlarmExists(context, position, launcherIntent)){
            if(presentTime.before(Calendar.getInstance()))
            {
                futureTime.setTime(presentTime.getTime());
                futureTime.add(Calendar.DATE, 1);
                manager.setExact(AlarmManager.RTC_WAKEUP, futureTime.getTimeInMillis(), pendingIntent);
            }
            else
            {
                manager.setExact(AlarmManager.RTC_WAKEUP, presentTime.getTimeInMillis(), pendingIntent);
            }
//        }


        alarmSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked){
                timesList.get(position).setStatus(true);
                if(presentTime.before(Calendar.getInstance()))
                {
                    futureTime.setTime(presentTime.getTime());
                    futureTime.add(Calendar.DATE, 1);
                    manager.setExact(AlarmManager.RTC_WAKEUP, futureTime.getTimeInMillis(), pendingIntent);
                }
                else
                {
                    manager.setExact(AlarmManager.RTC_WAKEUP, presentTime.getTimeInMillis(), pendingIntent);
                }

            }else{
                timesList.get(position).setStatus(false);
                manager.cancel(pendingIntent);
                pendingIntent.cancel();
                Toast.makeText(context, "Alarm is cancelled", Toast.LENGTH_SHORT).show();
            }
        });


        return convertView;
    }

/*
    public boolean isAlarmExists(Context context, int alarmId, Intent intent) {
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, alarmId, intent, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        return pendingIntent != null;
    }
*/

}
