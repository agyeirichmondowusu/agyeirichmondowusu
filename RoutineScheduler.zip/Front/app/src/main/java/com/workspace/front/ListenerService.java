package com.workspace.front;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class ListenerService extends Service {
    final String SERVICE_CHANNEL = "mainService";
    final int requestCode = 111;
    final int FOREGROUND_ID = 1;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.S)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createListenerServiceChannel();
        Intent mainActivityIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, requestCode, mainActivityIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Intent notificationIntent = new Intent(this, CancelNotification.class);
        PendingIntent actionIntent = PendingIntent.getBroadcast(this, 19, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
        Notification notification = new NotificationCompat.Builder(this,SERVICE_CHANNEL)
                .setSmallIcon(R.drawable.ic_notifications)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentTitle("Front is currently running")
                .setSilent(true)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setOnlyAlertOnce(true)
                .setColor(getColor(R.color.sea_blue))
                .addAction(R.drawable.ic_notifications, getString(R.string.stop),actionIntent)
                .setContentIntent(pendingIntent)
                .build();

        startForeground(FOREGROUND_ID, notification);
//        startService(new Intent(this, Music.class));
        return START_STICKY;
    }

    public void createListenerServiceChannel(){

        String name = getString(R.string.service);
        String description = getString(R.string.app_is_active);
        int importance = NotificationManager.IMPORTANCE_HIGH;
        NotificationChannel channel = new NotificationChannel(
                SERVICE_CHANNEL,
                name,
                importance
        );
        channel.setDescription(description);

        NotificationManagerCompat manager = NotificationManagerCompat.from(this);
        manager.createNotificationChannel(channel);
    }
}
