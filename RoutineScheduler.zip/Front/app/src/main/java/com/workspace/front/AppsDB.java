package com.workspace.front;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class AppsDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "AppsDb.db";
    private static final int DATABASE_VERSION = 1;
    //     TABLE INFO
    private static final String TABLE_NAME = "appsTable";
    private static final String PACKAGE_COLUMN = "package_name";
    private static final String TIME_COLUMN = "time";

    AppsDB(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String script = "CREATE TABLE " + TABLE_NAME + "("
                + PACKAGE_COLUMN + " TEXT, "
                + TIME_COLUMN + " TEXT"
                + ");";
        db.execSQL(script);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addPackage(AppPackageNames packageNames){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(PACKAGE_COLUMN, packageNames.getPackageName());
        cv.put(TIME_COLUMN, packageNames.getTime());

        return db.insert(TABLE_NAME, null, cv) != -1;
    }

    public void getAllPackages(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        AppPackageNames.packageNamesList.clear();
        if(cursor.moveToFirst()){
            do{
                int columnPackageIndex = cursor.getColumnIndex(PACKAGE_COLUMN);
                int columnTime = cursor.getColumnIndex(TIME_COLUMN);
                AppPackageNames.packageNamesList.add(new AppPackageNames(cursor.getString(columnPackageIndex), cursor.getString(columnTime)));
            }while (cursor.moveToNext());
        }
        cursor.close();

    }

    public void deleteAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_NAME);
        Apps.appsList.clear();
        db.close();
    }


}
