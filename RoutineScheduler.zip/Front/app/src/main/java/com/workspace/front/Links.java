package com.workspace.front;

import java.util.ArrayList;
import java.util.List;

public class Links {
    public static List<Links> linksList = new ArrayList<>();
    private final String title;
    private final String link;
    private final String time;
    private boolean status;

    public Links(String title, String link, String time, boolean status) {
        this.title = title;
        this.link = link;
        this.time = time;
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public String getLink() {
        return link;
    }

    public String getTime() {
        return time;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
