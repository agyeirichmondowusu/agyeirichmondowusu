package com.workspace.front;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.FrameLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    final int timeFrag = 0;
    final int linkFrag = 1;
    final int appFrag = 2;
    public static int lastSelectedIndex;
   /* private static final String TIME_ALARM_CHANNEL_ID = "timeAlarmChannel";
    private static final String LINK_ALARM_CHANNEL_ID = "linkAlarmChannel";*/
    TimeDB timeDB;
    LinkDB linkDB;
    AppsDB appsDB;
    TimeFragment timeFragment = new TimeFragment();
    LinksFragment linksFragment = new LinksFragment();
    AppsFragment appsFragment = new AppsFragment();

    FloatingActionButton fab, clearFab;
    BottomNavigationView navView;
    FrameLayout frameLayout;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*createNotificationChannel();
        createLinksNotificationChannel();*/
        getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, timeFragment).commit();

        fab = findViewById(R.id.fabAdd);
        clearFab = findViewById(R.id.clearAllData);
        navView = findViewById(R.id.bottomNavBar);
        frameLayout = findViewById(R.id.frame_layout);

        timeDB = new TimeDB(this);
        linkDB = new LinkDB(this);
        appsDB = new AppsDB(this);

        if (navView.getSelectedItemId() == R.id._alarm_time_) {
            timeDB.getAllTime();
            fab.setOnClickListener(view -> startActivity(new Intent(this, TimeActivity.class)));
            clearFab.setOnClickListener(view -> {
                timeDB.deleteAllTimeSet();
                timeFragment.timesListView.setAdapter(new TimeAdapter(this, R.layout.time_row_item, Times.myTimeClassList));
            });
        }
        if (navView.getSelectedItemId() == R.id._alarm_link_) {
            linkDB.getAllLinks();
            fab.setOnClickListener(view -> startActivity(new Intent(this, LinksActivity.class)));
            clearFab.setOnClickListener(view -> {
                linkDB.deleteAllTimeSet();
                linksFragment.linksListView.setAdapter(new LinksAdapter(this, R.layout.time_row_item, Links.linksList));
            });
        }

        navView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id._alarm_time_:
                    getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, timeFragment).commit();
                    timeDB.getAllTime();
                    fab.setOnClickListener(view -> {
                        Intent mainToTimeIntent = new Intent(this, TimeActivity.class);
                        startActivity(mainToTimeIntent);
                    });
                    clearFab.setOnClickListener(view -> {
                        timeDB.deleteAllTimeSet();
                        timeFragment.timesListView.setAdapter(new TimeAdapter(this, R.layout.time_row_item, Times.myTimeClassList));
                    });

                    return true;
                case R.id._alarm_link_:
                    getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, linksFragment).commit();
                    clearFab.setOnClickListener(view -> {
                        linkDB.deleteAllTimeSet();
                        LinksFragment.linksAdapter.notifyDataSetChanged();
                    });

                    fab.setOnClickListener(view -> startActivity(new Intent(this, LinksActivity.class)));
                    return true;
                case R.id._alarm_app_:
                    lastSelectedIndex = linkFrag;
                    getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, appsFragment).commit();
                    fillAppsListView();

                    fab.setOnClickListener(view -> startActivity(new Intent(this, AppsConfigActivity.class)));

                    clearFab.setOnClickListener(view -> {
                        appsDB.deleteAllData();
                        appsFragment.fragmentAppsList.setAdapter(new InstalledAppsAdapter(this, R.layout.app_row_item, Apps.appsList));
                    });
                    return true;

            }
            return false;
        });
        navView.getMenu().getItem(lastSelectedIndex).setChecked(true);

        if(!isRunning()){
            ContextCompat.startForegroundService(this, new Intent(this, ListenerService.class));
        }
    }

    public boolean isRunning() {
        boolean result = false;
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo serviceInfo : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (ListenerService.class.getName().equals(serviceInfo.service.getClassName())) {
                result = true;
                break;
            }
        }
        return result;
    }


    @Override
    protected void onResume() {

        if(navView.getSelectedItemId() == R.id._alarm_time_) {
            navView.getMenu().getItem(timeFrag).setChecked(true);
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, timeFragment).commit();
            timeDB.getAllTime();
            fab.setOnClickListener(view -> {
                Intent mainToTimeIntent = new Intent(this, TimeActivity.class);
                startActivity(mainToTimeIntent);
            });
            clearFab.setOnClickListener(view -> {
                timeDB.deleteAllTimeSet();
                timeFragment.timesListView.setAdapter(new TimeAdapter(this, R.layout.time_row_item, Times.myTimeClassList));
            });
        }else if(navView.getSelectedItemId() == R.id._alarm_link_){

            navView.getMenu().getItem(linkFrag).setChecked(true);
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, linksFragment).commit();
            clearFab.setOnClickListener(view -> {
                linkDB.deleteAllTimeSet();
                LinksFragment.linksAdapter.notifyDataSetChanged();
            });

            fab.setOnClickListener(view -> startActivity(new Intent(this, LinksActivity.class)));
        }
        if(navView.getSelectedItemId() == R.id._alarm_app_){
            lastSelectedIndex = appFrag;
            navView.getMenu().getItem(lastSelectedIndex).setChecked(true);
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, appsFragment).commit();
            fab.setOnClickListener(view -> startActivity(new Intent(this, AppsConfigActivity.class)));

            clearFab.setOnClickListener(view -> {
                appsDB.deleteAllData();
                appsFragment.fragmentAppsList.setAdapter(new InstalledAppsAdapter(this, R.layout.app_row_item, Apps.appsList));
            });
        }
        navView.getMenu().getItem(lastSelectedIndex).setChecked(true);
        super.onResume();

    }

   /* private void createNotificationChannel(){

        final Calendar calendar = Calendar.getInstance();
        String hour = String.valueOf(calendar.get(Calendar.HOUR_OF_DAY));
        String minute = String.valueOf(calendar.get(Calendar.MINUTE));
        CharSequence notificationName = getString(R.string.notification_name);
        String description = getString(R.string.time_set_for) + hour + getString(R.string.time_colon) + minute;
        int importance = NotificationManager.IMPORTANCE_HIGH;
        NotificationChannel channel = new NotificationChannel(
                TIME_ALARM_CHANNEL_ID,
                notificationName,
                importance
                );
        channel.setDescription(description);

        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        notificationManager.createNotificationChannel(channel);

    }
    private void createLinksNotificationChannel(){

        final Calendar calendar = Calendar.getInstance();
        String hour = String.valueOf(calendar.get(Calendar.HOUR_OF_DAY));
        String minute = String.valueOf(calendar.get(Calendar.MINUTE));
        CharSequence notificationName = "Link Alarm";
        String description = getString(R.string.time_set_for) + hour + getString(R.string.time_colon) + minute;
        int importance = NotificationManager.IMPORTANCE_HIGH;
        NotificationChannel channel = new NotificationChannel(
                LINK_ALARM_CHANNEL_ID,
                notificationName,
                importance
        );
        channel.setDescription(description);

        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        notificationManager.createNotificationChannel(channel);

    }

*/
    public void fillAppsListView() {
        appsDB.getAllPackages();
        if (AppPackageNames.packageNamesList.size() > 0) {
            AppsStatus.appsStatusList.clear();
            int index = 0;
            List<ApplicationInfo> applicationInfoList = getPackageManager().getInstalledApplications(PackageManager.GET_META_DATA);
            for (AppPackageNames packageNames : AppPackageNames.packageNamesList) {
                for (ApplicationInfo info : applicationInfoList) {
                    if (packageNames.getPackageName().equals(info.packageName)) {
                        AppsStatus.appsStatusList.add(new AppsStatus(true, new Apps(info.loadIcon(getPackageManager()), info.loadLabel(getPackageManager()).toString(), info.packageName), AppPackageNames.packageNamesList.get(index).getTime()));
                        Apps.appsList.add(new Apps(info.loadIcon(getPackageManager()), info.loadLabel(getPackageManager()).toString(), info.packageName));
                        break;
                    }
                }
                index++;
            }
        }
    }

}