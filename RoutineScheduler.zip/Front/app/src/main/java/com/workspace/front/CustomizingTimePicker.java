package com.workspace.front;

import android.content.Context;
import com.google.android.material.timepicker.MaterialTimePicker;
import com.google.android.material.timepicker.TimeFormat;

import java.util.Calendar;

public class CustomizingTimePicker{
    MaterialTimePicker.Builder builder;
    private MaterialTimePicker timePicker;
    private String actualTimeSet;
    private String time;
    private String hour;
    private String minute;
    Context context;
    public CustomizingTimePicker(Context context) {
        this.context = context;

    }

    public MaterialTimePicker createTimePicker(){
        builder = new MaterialTimePicker.Builder()
                .setHour(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))
                .setMinute(Calendar.getInstance().get(Calendar.MINUTE))
                .setInputMode(MaterialTimePicker.INPUT_MODE_KEYBOARD)
                .setTimeFormat(TimeFormat.CLOCK_12H)
                .setPositiveButtonText("Save")
                .setNegativeButtonText("Cancel")
                .setTitleText("Material Time Picker");

        return builder.build();
    }

    public void setTimePicker(MaterialTimePicker timePicker) {
        this.timePicker = timePicker;
    }

    public void showTimePicker(){
        setTimePicker(createTimePicker());
        timePicker.show(timePicker.getParentFragmentManager(), "timePicker");
    }

    public String getTimeSet(){
        showTimePicker();
        timePicker.addOnPositiveButtonClickListener(v -> {
            if(timePicker.getHour() < 10){
                hour = "0"+timePicker.getHour();
            }else{
                hour = ""+timePicker.getHour();
            }
            if(timePicker.getMinute() < 10){
                minute = "0"+timePicker.getMinute();
            }else{
                minute = ""+timePicker.getMinute();
            }
            time = hour +":"+ minute;
            setActualTimeSet(time);
        });

        timePicker.addOnNegativeButtonClickListener(v -> timePicker.dismiss());

        return getActualTimeSet();
    }

    public String getActualTimeSet(){
        return actualTimeSet;
    }
    public void setActualTimeSet(String time){
        actualTimeSet = time;
    }

}
