package com.workspace.front;

import java.util.ArrayList;
import java.util.List;

public class Times {
    public static List<Times> myTimeClassList = new ArrayList<>();

    private final String time;
    private boolean status;

    public Times(String time, boolean status) {
        this.time = time;
        this.status = status;
    }

    public String getTime() {
        return time;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status){
        this.status = status;
    }
}
