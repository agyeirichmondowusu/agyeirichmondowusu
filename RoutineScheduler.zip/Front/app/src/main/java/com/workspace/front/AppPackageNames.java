package com.workspace.front;

import java.util.ArrayList;
import java.util.List;

public class AppPackageNames {
    public static List<AppPackageNames> packageNamesList = new ArrayList<>();
    private final String packageName;
    private final String time;

    public AppPackageNames(String packageName, String time) {
        this.packageName = packageName;
        this.time = time;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getTime() {
        return time;
    }
}
