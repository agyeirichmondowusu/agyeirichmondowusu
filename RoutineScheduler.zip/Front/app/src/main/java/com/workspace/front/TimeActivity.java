package com.workspace.front;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.timepicker.MaterialTimePicker;

public class TimeActivity extends AppCompatActivity {

    FloatingActionButton fabAddTime;
    private static final int TIME_DEFAULT_INDEX = 0;
    TextView txtDisplayTime;
    AppCompatButton btnCancel, btnSave;
    MaterialTimePicker materialTimePicker;
    String time;
    static int position;
    static String savedTime;
    TimeDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);
        materialTimePicker = CreatePicker.createTimePicker();

        time = "";
        db = new TimeDB(this);
        fabAddTime = findViewById(R.id.timeAddAlarm);
        txtDisplayTime = findViewById(R.id.txtTimeSet);
        btnCancel = findViewById(R.id.btnCancel);
        btnSave = findViewById(R.id.btnSave);
        showTimePicker();

        fabAddTime.setOnClickListener(view -> showTimePicker());

        btnSave.setOnClickListener(view -> {

            if (!txtDisplayTime.getText().toString().isEmpty()) {
                setCorrectTimeFormat();


                if (db.addTime(new Times(time, true))) {
                    db.getAllTime();
                    materialTimePicker.dismiss();
//                    timePicker.dismiss();
                    onBackPressed();

                    Toast.makeText(this, getText(R.string.alarm_set_prompt), Toast.LENGTH_SHORT).show();
                }

            }else{
                Toast.makeText(this, getText(R.string.please_set_time), Toast.LENGTH_SHORT).show();
            }
        });

        btnCancel.setOnClickListener(view -> onBackPressed());
    }

    public void setCorrectTimeFormat(){
        time = CreatePicker.formatAlarmTime(materialTimePicker.getHour(), materialTimePicker.getMinute());
    }

    public void showTimePicker(){
        materialTimePicker.show(getSupportFragmentManager(), "time");
        materialTimePicker.addOnPositiveButtonClickListener(p -> {
            setCorrectTimeFormat();
            txtDisplayTime.setText(time);
            txtDisplayTime.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));
        });

        materialTimePicker.addOnNegativeButtonClickListener(n -> materialTimePicker.dismiss());
    }

    @Override
    protected void onResume() {
        if(!txtDisplayTime.getText().toString().isEmpty()){
            txtDisplayTime.setText(time);
        }
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        MainActivity.lastSelectedIndex = TIME_DEFAULT_INDEX;
        super.onBackPressed();
    }

    public static void setPosition(int position) {
        TimeActivity.position = position;
    }
}