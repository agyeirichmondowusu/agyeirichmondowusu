package com.workspace.front;

import static com.workspace.front.App.APP_CHANNEL;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class AppAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String package_name = intent.getStringExtra("packageName");
        Intent launchApp = context.getPackageManager().getLaunchIntentForPackage(package_name);
        if(launchApp != null){
            Intent returnToLinkSection = new Intent(context, MainActivity.class);
            MainActivity.lastSelectedIndex = 2;
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 50, returnToLinkSection, PendingIntent.FLAG_UPDATE_CURRENT);
            Notification notification = new NotificationCompat.Builder(context, APP_CHANNEL)
                    .setSmallIcon(R.drawable.ic_notifications)
                    .setOngoing(false)
                    .setAutoCancel(true)
                    .setContentTitle("App Alarm!")
                    .setContentText("launching package \"" + package_name +"\"")
                    .setColor(context.getColor(R.color.sea_blue))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setContentIntent(pendingIntent)
                    .build();

            NotificationManager manager = context.getSystemService(NotificationManager.class);
            manager.notify(222, notification);

            context.startActivity(launchApp);
        }
        else {
            Toast.makeText(context, "Unable to launch application", Toast.LENGTH_SHORT).show();
        }
        
        Toast.makeText(context, "Package received " + package_name, Toast.LENGTH_SHORT).show();
    }
}
