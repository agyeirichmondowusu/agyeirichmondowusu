package com.workspace.front;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;
import java.util.Calendar;
import java.util.List;

public class LinksAdapter extends BaseAdapter {
    Context context;
    int resource;
    List<Links> linksList;
    final Calendar presentCalendar = Calendar.getInstance();
    final Calendar futureCalendar = Calendar.getInstance();
    AlarmManager manager;

    public LinksAdapter(Context context, int resource, List<Links> linksList) {
        this.context = context;
        this.resource = resource;
        this.linksList = linksList;
    }

    @Override
    public int getCount() {
        return linksList.size();
    }

    @Override
    public Object getItem(int position) {
        return linksList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return getView(position, null, null).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        if(convertView == null){
            convertView = inflater.inflate(resource, parent, false);
        }
        TextView titleTv = convertView.findViewById(R.id.linkTitle);
        TextView linkTv = convertView.findViewById(R.id.linkUrl);
        TextView timeTv = convertView.findViewById(R.id.linkTime);
        SwitchCompat linkSwitch = convertView.findViewById(R.id.linkSwitch);

        linkSwitch.setChecked(linksList.get(position).getStatus());

        titleTv.setText(linksList.get(position).getTitle());
        linkTv.setText(linksList.get(position).getLink());
        timeTv.setText(linksList.get(position).getTime());

        String timeSet = linksList.get(position).getTime();
        String[] split_time = timeSet.split(":");
        int _hour = Integer.parseInt(split_time[0]);
        int _minute = Integer.parseInt(split_time[1]);

        presentCalendar.set(Calendar.HOUR_OF_DAY, _hour);
        presentCalendar.set(Calendar.MINUTE, _minute);
        presentCalendar.set(Calendar.SECOND, 0);
        presentCalendar.set(Calendar.MILLISECOND, 0);

        Intent linkIntent = new Intent(context, LinkAlarmReceiver.class );
        linkIntent.putExtra("position", position);
        linkIntent.putExtra("link", linksList.get(position).getLink());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, position, linkIntent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);


        manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

//        if(linkSwitch.isChecked()){
            if(presentCalendar.before(Calendar.getInstance())){
                futureCalendar.setTime(presentCalendar.getTime());
                futureCalendar.add(Calendar.DATE, 1);
                manager.setExact(AlarmManager.RTC_WAKEUP, futureCalendar.getTimeInMillis(), pendingIntent);
            }else{
                manager.setExact(AlarmManager.RTC_WAKEUP, presentCalendar.getTimeInMillis(), pendingIntent);
            }
//        }


        linkSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked){
                linkSwitch.setChecked(true);
                if(presentCalendar.before(Calendar.getInstance().getTime())){
                    futureCalendar.setTime(presentCalendar.getTime());
                    futureCalendar.add(Calendar.DATE, 1);
                    manager.setExact(AlarmManager.RTC_WAKEUP, futureCalendar.getTimeInMillis(), pendingIntent);
                }else{
                    manager.setExact(AlarmManager.RTC_WAKEUP, presentCalendar.getTimeInMillis(), pendingIntent);
                }

            }else{
                linkSwitch.setChecked(false);
                manager.cancel(pendingIntent);
                pendingIntent.cancel();
            }
        });


        return convertView;
    }
}
