package com.workspace.front;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class InstalledAppsAdapter extends BaseAdapter {
    Context context;
    int resource;
    List<Apps> appsList;
    HashSet<Apps> appsHashSet;

    public InstalledAppsAdapter(Context context, int resource, List<Apps> appsList) {
        this.context = context;
        this.resource = resource;
        appsHashSet = new HashSet<>(appsList);
        this.appsList = new ArrayList<>(appsHashSet);
    }

    @Override
    public int getCount() {
        return appsList.size();
    }

    @Override
    public Object getItem(int position) {
        return appsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return getView(position, null, null).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        if(convertView == null){
            convertView = inflater.inflate(resource, parent, false);
        }
        convertView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.slide_in_bounce));
        ImageView appIcon = convertView.findViewById(R.id.appIcon);
        TextView appLabel = convertView.findViewById(R.id.appLabel);

        appIcon.setImageDrawable(appsList.get(position).getIcon());
        appLabel.setText(appsList.get(position).getLabel());

        return convertView;
    }
}
